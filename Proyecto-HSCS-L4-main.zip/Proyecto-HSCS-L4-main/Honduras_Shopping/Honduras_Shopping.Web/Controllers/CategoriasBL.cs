﻿using System;

namespace Honduras_Shopping.Web.Controllers
{
    internal class CategoriasBL
    {
        internal object ObtenerCategorias()
        {
            throw new NotImplementedException();
        }
    }
}